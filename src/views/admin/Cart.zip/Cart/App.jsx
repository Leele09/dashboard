import Francemap from "./components/Francemap";
import React,{Component} from 'react';
import './App.css';
//import LocationSearch from "./components/LocationSearch";


// Point d'entrée de l'application//
function App() {
    return (
        <div className="App">
            <Francemap />
        </div>
    );
}
export default App;
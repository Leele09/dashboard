//import React from "react";
//import ReactDOM from "react-dom";
//import App from "./App"; // Importez le composant App
//import "./components/Card/Card.css"; // Importez le fichier CSS
//import Francemap from "./components/Francemap"; // Importez le composant Francemap

// Point d'entrée de l'application//
//const MainApp = () => { // Renommez App en MainApp
  //  const ref = React.useRef(null);
    //const [map, setMap] = React.useState();

    //return (
     //   <Francemap />
    //);
//};

//ReactDOM.render(<MainApp />, document.getElementById("root")); // Utilisez MainApp au lieu de App


